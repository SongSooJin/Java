package w10;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

class MyActionListener implements ActionListener{
	String gase = "@@@";
	static String name = "@@@";
	
	public void actionPerformed(ActionEvent e) {
		JButton b = (JButton)e.getSource();
		if(b.getText().equals("�Է�")) {
			gase=JOptionPane.showInputDialog("�̸��� �Է��ϼ���");
			String st = new String(gase);
			name =st;
			//System.out.println(st);
		}
//		if(b.getText().equals("�Է�")) {
//			name=JOptionPane.showInputDialog("�̸��� �Է��ϼ���");
//		}
		if(b.getText().equals("���")) {
			JOptionPane.showMessageDialog(null,"�̸��� "+name+ "�Դϴ�.");
		}
		if(b.getText().equals("����")) {
			JOptionPane.showMessageDialog(null,"�����մϴ�");
			System.exit(0);//����
		}
	}
	
}

class MyFrame extends JFrame {
	static final long serialVersionUID=0L; 
	
	public MyFrame() {
		
		Container c = getContentPane();
		c.setBackground(Color.orange);
		c.setLayout(new FlowLayout());
		JButton b1 = new JButton("�Է�");
		b1.addActionListener(new MyActionListener());
		c.add(b1); 
		
		JButton b2 = new JButton("���");
		b2.addActionListener(new MyActionListener());
		c.add(b2); 
		
		JButton b3 = new JButton("����");
		b3.addActionListener(new MyActionListener());
		c.add(b3); 
		
		setSize(300,150);
		setTitle("�۾�â");
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
}

public class Ex_�׽�Ʈ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new MyFrame();

		
	}

}
