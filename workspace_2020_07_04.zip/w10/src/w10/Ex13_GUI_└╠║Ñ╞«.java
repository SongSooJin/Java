package w10;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

class YourActionListener implements ActionListener{
	String gase = "@@@";
	static double ga = 0.0;
	static double se = 0.0;
	
	public void actionPerformed(ActionEvent e) {
		JButton b = (JButton)e.getSource();
		if(b.getText().equals("�Է�")) {
			gase=JOptionPane.showInputDialog("����,���θ� �Է��ϼ���");
			StringTokenizer st = new StringTokenizer(gase,",");
			se = Double.parseDouble(st.nextToken()); //���ڿ� 10.3�� double��
			ga = Double.parseDouble(st.nextToken()); 
		}
		if(b.getText().equals("���")) {
			String ss = "���� : " + ga + "���� : " + se+"\n���� : "+(ga*se);
			JOptionPane.showMessageDialog(null,ss);
		}
		if(b.getText().equals("����")) {
			JOptionPane.showMessageDialog(null,"�����մϴ�");
			System.exit(0);//����
		}
	}
	
}

class YourFrame extends JFrame {
	static final long serialVersionUID=0L; 
	
	public YourFrame() {
		
		Container c = getContentPane();
		c.setBackground(Color.orange);
		c.setLayout(new FlowLayout());
		JButton b1 = new JButton("�Է�");
		b1.setBackground(Color.BLUE);
		b1.addActionListener(new YourActionListener());
		c.add(b1); 
		
		JButton b2 = new JButton("���");
		b2.setBackground(Color.BLUE);
		b2.addActionListener(new YourActionListener());
		c.add(b2); 
		
		JButton b3 = new JButton("����");
		b3.addActionListener(new YourActionListener());
		b3.setBackground(Color.BLUE);
		c.add(b3); 
		
		setSize(300,150);
		setTitle("�Է�â");
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
}

public class Ex13_GUI_�̺�Ʈ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new YourFrame();

		
	}

}
