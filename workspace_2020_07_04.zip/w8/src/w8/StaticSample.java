package w8;

public class StaticSample {
		int n;
		void g() {System.out.println("void g()...");}
		static int m;
		static void f() {System.out.println("void f()...");}
			


}
