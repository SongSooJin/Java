package q;

 class D {

	 void h() {
		 C c = new C();
	 }
}
