package q;


public class C {

	 void g() {
		 B b = new B();
	 }
	
}
