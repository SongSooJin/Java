package q;

public class B {


}
