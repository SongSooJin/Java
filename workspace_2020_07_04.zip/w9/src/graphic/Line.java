package graphic;

import ui.Tools;

class Shape {
	
}

public class Line extends Shape{

		public void draw() {
			Tools t = new Tools();
		}

}
