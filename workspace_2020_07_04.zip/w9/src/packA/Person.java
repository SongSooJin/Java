package packA;

public class Person {

}

class Student extends Person {
	
}

class Researcher extends Person {
	
}

class Professor extends Researcher {
	
}