package w9;

public class InterfaceEx {
	

	public static void main(String[] args) {

		SmartPhone p = new SmartPhone();
		p.sendCall();
		p.play();
		System.out.println(p.calculate(3,5));
		p.schedule();
		
	}

}


