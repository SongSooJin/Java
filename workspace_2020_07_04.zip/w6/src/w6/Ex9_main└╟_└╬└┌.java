package w6;

public class Ex9_main��_���� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String a = args[0]; // a�� "abc"
		String b = args[1]; // b�� "3"
		String c = args[2]; // c�� "%"
		String d = args[3]; // d�� "5.7"
		System.out.println("a: " + a);
		System.out.println("b: " + b);
		System.out.println("c: " + c);
		System.out.println("d: " + d);
		

	}

}
